package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.TextView
import com.google.android.material.bottomnavigation.BottomNavigationView
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController

class MainActivity : AppCompatActivity() {

    lateinit var Fiebre: CheckBox
    lateinit var Perdida: CheckBox
    lateinit var PerdidaGusto: CheckBox
    lateinit var Tos: CheckBox
    lateinit var CongestionNasal: CheckBox
    lateinit var DificultadRespirar: CheckBox
    lateinit var AumentoRespiracion: CheckBox
    lateinit var DolorGarganta: CheckBox
    lateinit var DolorMuscular: CheckBox
    lateinit var DebilidadGeneral: CheckBox
    lateinit var DolorPecho: CheckBox
    lateinit var Escalofrios: CheckBox
    lateinit var Diarrea: CheckBox
    lateinit var PerdidaApetito: CheckBox
    lateinit var DolorCabeza: CheckBox

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val textView: TextView = findViewById(R.id.tvResultado1) as TextView


        Fiebre = findViewById(R.id.cb1)
        Perdida = findViewById(R.id.cb2)
        PerdidaGusto = findViewById(R.id.cb3)
        Tos= findViewById(R.id.cb4)
        CongestionNasal = findViewById(R.id.cb5)
        DificultadRespirar = findViewById(R.id.cb6)
        AumentoRespiracion = findViewById(R.id.cb7)
        DolorGarganta = findViewById(R.id.cb8)
        DolorMuscular = findViewById(R.id.cb9)
        DebilidadGeneral = findViewById(R.id.cb10)
        DolorPecho = findViewById(R.id.cb11)
        Escalofrios = findViewById(R.id.cb12)
        Diarrea = findViewById(R.id.cb13)
        PerdidaApetito = findViewById(R.id.cb14)
        DolorCabeza = findViewById(R.id.cb15)
        var totalAmount: Int = 0
        val result = StringBuilder()
        result.append("Selected Items")
        if (Fiebre.isChecked) {
            totalAmount += 1
        }
        if (Perdida.isChecked) {
            totalAmount += 1
        }
        if (PerdidaGusto.isChecked) {
            totalAmount += 1
        }
        if (Tos.isChecked) {
            totalAmount += 1
        }
        if (CongestionNasal.isChecked) {
            totalAmount += 1
        }
        if (DificultadRespirar.isChecked) {
            totalAmount += 1
        }
        if (AumentoRespiracion.isChecked) {
            totalAmount += 1
        }
        if (DolorGarganta.isChecked) {
            totalAmount += 1
        }
        if (DolorMuscular.isChecked) {
            totalAmount += 1
        }
        if (DebilidadGeneral.isChecked) {
            totalAmount += 1
        }
        if (DolorPecho.isChecked) {
            totalAmount += 1
        }
        if (Escalofrios.isChecked) {
            totalAmount += 1
        }
        if (Diarrea.isChecked) {
            totalAmount += 1
        }
        if (PerdidaApetito.isChecked) {
            totalAmount += 1
        }
        if (DolorCabeza.isChecked) {
            totalAmount += 1
        }
        if (totalAmount >= 3) {
            textView.text = "PODRÍA TENER COVID, \nCONSULTE CON UN MÉDICO CUANTO ANTES"
        } else {
            textView.text = "NO HAY SUFICIENTES SINTOMAS"
        }


        val navView: BottomNavigationView = findViewById(R.id.nav_view)

        val navController = findNavController(R.id.nav_host_fragment)
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        val appBarConfiguration = AppBarConfiguration(setOf(
                R.id.navigation_information, R.id.navigation_calculator, R.id.navigation_checklist))
        setupActionBarWithNavController(navController, appBarConfiguration)
        navView.setupWithNavController(navController)



    }
}